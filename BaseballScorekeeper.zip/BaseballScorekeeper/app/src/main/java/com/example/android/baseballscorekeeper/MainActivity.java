package com.example.android.baseballscorekeeper;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int visitorScore = 0;
    int homeScore = 0;
    int outs = 0;
    int inning = 1;
    boolean visitorAtBat = true;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayScoreVisitor(visitorScore);
        displayScoreHome(homeScore);
        displayOutVisitor(outs);
        displayOutHome(outs);
        displayInningAndBatter();
        displayButtons();
    }

    /**
     * Displays the given score for Visitor.
     */
    public void displayScoreVisitor(int score) {
        TextView visitorScoreView = (TextView) findViewById(R.id.visitor_score);
        visitorScoreView.setText(String.valueOf(score));
    }

    /**
     * Displays the outs for Visitor.
     */
    public void displayOutVisitor(int out) {
        TextView visitorOutView = (TextView) findViewById(R.id.visitor_out);
        visitorOutView.setText(String.valueOf(out + " Out"));
    }

    /**
     * Increments the score for Visitor ONLY if visitors are at bat.
     */
    public void buttonPressVisitorRunScored(View view) {
        visitorScore = visitorScore + 1;
        displayScoreVisitor(visitorScore);
    }

    /**
     * Increments the outs for Visitor.
     * If Outs are currently at 2, then set outs to 0,
     * set visitorAtBat to False, display visitor outs and inning info.
     */
    public void buttonPressVisitorOut(View view) {
        if (outs == 2) {
            outs = 0;
            visitorAtBat = false;
            displayInningAndBatter();
            displayButtons();
        } else {
            outs = outs + 1;
        }
        displayOutVisitor(outs);
    }

    /**
     * Displays the given score for Home.
     */
    public void displayScoreHome(int score) {
        TextView scoreHomeView = (TextView) findViewById(R.id.home_score);
        scoreHomeView.setText(String.valueOf(score));
    }

    /**
     * Displays the outs for Home.
     */
    public void displayOutHome(int out) {
        TextView home_outView = (TextView) findViewById(R.id.home_out);
        home_outView.setText(String.valueOf(out + " Out"));
    }

    /**
     * Increments the score for Home ONLY if Home are at bat (visitors are not at bat).
     */
    public void buttonPressHomeRunScore(View view) {
        homeScore = homeScore + 1;
        displayScoreHome(homeScore);
    }

    /**
     * Increments the outs for Home ONLY if Home is at bat (visitors are not at bat).
     * If Outs are currently at 2, then set outs to 0,
     * set visitorAtBat to True, display visitor outs and inning info.
     */
    public void buttonPressHomeOut(View view) {
        if (outs == 2) {
            outs = 0;
            visitorAtBat = true;
            inning = inning + 1;
            displayInningAndBatter();
            displayButtons();
        } else {
            outs = outs + 1;
        }
        displayOutHome(outs);
    }

    /**
     * Displays the inning and at bat if the inning is 9 or less,
     * otherwise it displays end of game.
     */
    public void displayInningAndBatter() {
        TextView inningAtBatView = (TextView) findViewById(R.id.inningAtBat);
        String atBat;
        if (inning > 9) {
            inningAtBatView.setText(String.valueOf("Final Score"));
        } else {
            if (visitorAtBat) {
                atBat = "Visitor";
            } else {
                atBat = "Home";
            }
            inningAtBatView.setText(String.valueOf("Inning:    " + inning + "       At Bat:  " + atBat));
        }
    }

    public void buttonPressReset(View view) {
        visitorScore = 0;
        homeScore = 0;
        outs = 0;
        inning = 1;
        visitorAtBat = true;
        displayScoreVisitor(visitorScore);
        displayScoreHome(homeScore);
        displayOutVisitor(outs);
        displayOutHome(outs);
        displayInningAndBatter();
        displayButtons();

    }

    public void displayButtons() {
        Button homeScore = (Button) findViewById(R.id.homeScoreButton);
        Button homeOut = (Button) findViewById(R.id.homeOutButton);
        Button visitorScore = (Button) findViewById(R.id.visitorScoreButton);
        Button visitorOut = (Button) findViewById(R.id.visitorOutButton);

        if (inning > 9) {
            homeScore.setTextColor(Color.parseColor("#C8E6C9"));
            homeScore.setBackgroundColor(Color.parseColor("#A5D6A7"));
            homeScore.setClickable(false);
            homeOut.setTextColor(Color.parseColor("#C8E6C9"));
            homeOut.setBackgroundColor(Color.parseColor("#A5D6A7"));
            homeOut.setClickable(false);
        } else {
            if (visitorAtBat) {
                /** Disable Home Team Buttons */
                homeScore.setTextColor(Color.parseColor("#C8E6C9"));
                homeScore.setBackgroundColor(Color.parseColor("#A5D6A7"));
                homeScore.setClickable(false);
                homeOut.setTextColor(Color.parseColor("#C8E6C9"));
                homeOut.setBackgroundColor(Color.parseColor("#A5D6A7"));
                homeOut.setClickable(false);

                /** Enable Home Team Buttons */
                visitorScore.setTextColor(Color.parseColor("#000000"));
                visitorScore.setBackgroundColor(Color.parseColor("#4CAF50"));
                visitorScore.setClickable(true);
                visitorOut.setTextColor(Color.parseColor("#000000"));
                visitorOut.setBackgroundColor(Color.parseColor("#4CAF50"));
                visitorOut.setClickable(true);
            } else {
                /** Enable Home Team Buttons */
                homeScore.setTextColor(Color.parseColor("#000000"));
                homeScore.setBackgroundColor(Color.parseColor("#4CAF50"));
                homeScore.setClickable(true);
                homeOut.setTextColor(Color.parseColor("#000000"));
                homeOut.setBackgroundColor(Color.parseColor("#4CAF50"));
                homeOut.setClickable(true);

                /** Disable Home Team Buttons */
                visitorScore.setTextColor(Color.parseColor("#C8E6C9"));
                visitorScore.setBackgroundColor(Color.parseColor("#A5D6A7"));
                visitorScore.setClickable(false);
                visitorOut.setTextColor(Color.parseColor("#C8E6C9"));
                visitorOut.setBackgroundColor(Color.parseColor("#A5D6A7"));
                visitorOut.setClickable(false);

            }
        }

    }
}
